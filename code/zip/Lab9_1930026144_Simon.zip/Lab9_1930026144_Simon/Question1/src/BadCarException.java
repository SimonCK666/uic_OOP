
public class BadCarException extends Exception {
    public BadCarException(String msg) {
        super(msg);
    }
}
