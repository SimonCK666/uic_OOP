
public class Start {
    public static void main(String[] args) {
        // test Door class
        Door.testDoor();
        // test Car class
        Car.testCar();
    }
}
