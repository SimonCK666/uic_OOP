
public class BadDoorException extends Exception {
    public BadDoorException(String msg) {
        super(msg);
    }
}
