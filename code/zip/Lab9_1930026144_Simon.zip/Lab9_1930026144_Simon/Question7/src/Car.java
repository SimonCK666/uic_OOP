import java.util.ArrayList;

public class Car {
    private String name;
    private ArrayList<Door> doors;

    public Car(String name, int numberOfDoors) throws BadCarException {
        // create the constructor
        this.name = name;
        if (numberOfDoors < 1) {
            throw new BadCarException("A car must have at least one door!");
        } else {
            doors = new ArrayList<Door>();
            for (int i = 0; i < numberOfDoors; i++) {
                doors.add(new Door());
            }
        }
    }

    public void listDoors() {
        for (Door doors : doors) {
            if (doors.isOpen() == true) {
                System.out.println(name + ", door is closed");
            } else {
                System.out.println(name + ", door is open");
            }
        }
    }

    public int countOpenDoors() {
        // counts the number of doors of the car which are currently open
        int numOfopenDoors = 0;
        for (Door doors : doors) {
            if (doors.isOpen() == true) {
                numOfopenDoors++;
            }
        }
        return numOfopenDoors;
    }

    public void openOneDoor(int doorNumber) throws BadDoorException {
        // open a specific door
        if (doorNumber < 1 || doorNumber > doors.size()) {
            throw new BadDoorException("Door " + doorNumber + " ddes not exist!");
        } else {
            doors.get(doorNumber - 1).open();
        }
    }

    public void changeAllDoors() {
        // opens all the closed doors of the car and closes all the open doors of the car
        for (Door doors : doors) {
            if (doors.isOpen() == true) {
                doors.close();
            } else {
                doors.open();
            }
        }
    }

    public void replaceDoor(int doorNumber) throws BadDoorException {
        // replace the existing car door
        if (doorNumber < 1 || doorNumber > doors.size()) {
            throw new BadDoorException("Door" + doorNumber + " does not exist");
        } else {
            doors.set(doorNumber - 1, new Door());
        }
    }

    public void replaceDoor() {
        // without arguement
        for ( int i = 0; i < doors.size(); i++) {
            doors.set(i, new Door());
        }
    }

    public void replaceManyDoors(int numberOfDoorsToReplace) {
        // indicates the number of existing car doors that should be replaced with completely new doors
        for ( int i = 0; i < numberOfDoorsToReplace; i++) {
            doors.set(i, new Door());
        }
    }

    public void expandCar() {
        // add tow vew doors to the car the existing doors should not be modified
        // Door[] de = new Door[doors.length + 2];
        // for ( int i = 0; i < doors.length; i++) {
        //     de[i] = doors[i];
        // }
        // de[doors.length] = new Door();
        // de[doors.length + 1] = new Door();
        // doors = de;
        doors.add(new Door());
        doors.add(new Door());
    }

    public static void testCar() {
        try {
            Car c = new Car("H", 0);
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage().equals("Car must has at least a door"));
        }
        try {
            Car c = new Car("H", 4);
            c.openOneDoor(0);
        } catch (BadCarException | BadDoorException e) {
            // TODO: handle exception
            System.out.println(e.getMessage().equals("Door 0 does not exist"));
        }
        try {
            Car c = new Car("H", 4);
            c.openOneDoor(5);
        } catch (BadCarException | BadDoorException e) {
            // TODO: handle exception
            System.out.println(e.getMessage().equals("Door 5 does not exist"));

        }
        try {
            Car c = new Car("H", 4);
            // list the doors
            c.listDoors();
            System.out.println(c.countOpenDoors() == 0);
            c.openOneDoor(1);
            c.listDoors();
            System.out.println(c.countOpenDoors() == 1);

            // test the changeAllDoors method
            c.changeAllDoors();
            c.listDoors();


            // test the replceDoor method
            c.replaceDoor(2);
            c.listDoors();

            // test the replaceDoor without arguement
            c.replaceDoor();
            c.listDoors();

            // test the replaceManyDoors method
            c.replaceManyDoors(3);

            // test teh expandCar method
            c.expandCar();
            c.listDoors();

            

        } catch (BadCarException | BadDoorException e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
        }
    }
}
