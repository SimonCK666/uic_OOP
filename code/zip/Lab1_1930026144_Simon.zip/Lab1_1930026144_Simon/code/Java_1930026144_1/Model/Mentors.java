
import java.util.*;

/**
 * 
 */
public class Mentors {

    /**
     * Default constructor
     */
    public Mentors() {
    }

    /**
     * 
     */
    public void emailAddress;


    /**
     * 
     */
    public void getEmailAddress() {
        // TODO implement here
    }

}