
import java.util.*;

/**
 * 
 */
public class Person extends Students {

    /**
     * Default constructor
     */
    public Person() {
    }

    /**
     * 
     */
    public void MobilePhoneNumber;

}