
import java.util.*;

/**
 * 
 */
public class Teachers extends Person {

    /**
     * Default constructor
     */
    public Teachers() {
    }

    /**
     * 
     */
    public void office number;

    /**
     * 
     */
    public void staff ID number;

    /**
     * 
     */
    public void officePhoneNumber;


}