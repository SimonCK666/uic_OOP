
import java.util.*;

/**
 * 
 */
public class Students extends Person {

    /**
     * Default constructor
     */
    public Students() {
    }

    /**
     * 
     */
    public void studentID;

    /**
     * 
     */
    public void dormitory number;

    /**
     * 
     */
    public void major;

    /**
     * 
     */
    public void homeAddress;

}