
import java.util.*;

/**
 * 
 */
public class Security Guards extends Person {

    /**
     * Default constructor
     */
    public Security Guards() {
    }

    /**
     * 
     */
    public void staffIDNumber;

}