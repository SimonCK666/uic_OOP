
import java.util.*;

/**
 * 
 */
public class TA extends GraduateStudent {

    /**
     * Default constructor
     */
    public TA() {
    }




}