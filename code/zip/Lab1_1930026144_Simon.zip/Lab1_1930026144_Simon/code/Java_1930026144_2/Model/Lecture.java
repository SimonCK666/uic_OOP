
import java.util.*;

/**
 * 
 */
public class Lecture extends Teacher {

    /**
     * Default constructor
     */
    public Lecture() {
    }


    /**
     * 
     */
    public void getMostTwoTAs() {
        // TODO implement here
    }

}