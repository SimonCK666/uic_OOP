
import java.util.*;

/**
 * 
 */
public class College {

    /**
     * Default constructor
     */
    public College() {
    }

    /**
     * 
     */
    public void Teachers;

    /**
     * 
     */
    public void Students;



}