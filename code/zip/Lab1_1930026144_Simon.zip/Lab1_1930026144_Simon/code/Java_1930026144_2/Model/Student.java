
import java.util.*;

/**
 * 
 */
public class Student {

    /**
     * Default constructor
     */
    public Student() {
    }

    /**
     * 
     */
    public void Attribute1;

    /**
     * 
     */
    public void graduate students;

    /**
     * 
     */
    public void undergraduate students;


}