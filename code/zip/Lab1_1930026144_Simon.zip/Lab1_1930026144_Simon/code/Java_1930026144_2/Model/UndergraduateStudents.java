
import java.util.*;

/**
 * 
 */
public class UndergraduateStudents extends Student {

    /**
     * Default constructor
     */
    public UndergraduateStudents() {
    }

}