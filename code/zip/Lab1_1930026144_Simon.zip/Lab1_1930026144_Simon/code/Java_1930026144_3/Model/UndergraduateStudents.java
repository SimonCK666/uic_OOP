
import java.util.*;

/**
 * 
 */
public class UndergraduateStudents extends Students {

    /**
     * Default constructor
     */
    public UndergraduateStudents() {
    }



}