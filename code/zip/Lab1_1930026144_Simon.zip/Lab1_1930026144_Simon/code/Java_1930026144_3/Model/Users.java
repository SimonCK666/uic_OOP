
import java.util.*;

/**
 * 
 */
public interface Users {



    /**
     * 
     */
    public void searchBooks();

    /**
     * 
     */
    public void borrowBooks();

    /**
     * 
     */
    public void returnBooks();

}