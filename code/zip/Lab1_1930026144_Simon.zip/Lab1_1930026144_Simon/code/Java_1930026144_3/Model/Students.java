
import java.util.*;

/**
 * 
 */
public class Students implements Users {

    /**
     * Default constructor
     */
    public Students() {
    }

    /**
     * 
     */
    public void Undergraduate students;

    /**
     * 
     */
    public void Graduate students;

    /**
     * 
     */
    public void studentIDNumber;

    /**
     * 
     */
    public void searchBooks() {
        // TODO implement here
    }

    /**
     * 
     */
    public void borrowBooks() {
        // TODO implement here
    }

    /**
     * 
     */
    public void returnBooks() {
        // TODO implement here
    }

}