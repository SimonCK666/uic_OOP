
import java.util.*;

/**
 * 
 */
public class Teachers implements Users {

    /**
     * Default constructor
     */
    public Teachers() {
    }

    /**
     * 
     */
    public void staffIDNumber;


    /**
     * 
     */
    public void searchBooks() {
        // TODO implement here
    }

    /**
     * 
     */
    public void borrowBooks() {
        // TODO implement here
    }

    /**
     * 
     */
    public void returnBooks() {
        // TODO implement here
    }

}