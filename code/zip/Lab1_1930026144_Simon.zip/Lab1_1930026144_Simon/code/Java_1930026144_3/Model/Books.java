
import java.util.*;

/**
 * 
 */
public class Books extends Library {

    /**
     * Default constructor
     */
    public Books() {
    }

    /**
     * 
     */
    public void ISBNNumber;

    /**
     * 
     */
    public void statusIndicating;


}