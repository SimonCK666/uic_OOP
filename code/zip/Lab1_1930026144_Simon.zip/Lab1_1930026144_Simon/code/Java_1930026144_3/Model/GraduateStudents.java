
import java.util.*;

/**
 * 
 */
public class GraduateStudents extends Students {

    /**
     * Default constructor
     */
    public GraduateStudents() {
    }


}