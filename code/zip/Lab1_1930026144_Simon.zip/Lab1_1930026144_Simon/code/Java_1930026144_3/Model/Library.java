
import java.util.*;

/**
 * 
 */
public class Library {

    /**
     * Default constructor
     */
    public Library() {
    }

    /**
     * 
     */
    public void Books;



}