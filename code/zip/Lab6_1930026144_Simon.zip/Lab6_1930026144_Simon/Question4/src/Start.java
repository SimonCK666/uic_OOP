
public class Start {
    public static void main(String[] args) {
        // test the Shape class
        Shape.testShape();
        // test the Circle class
        Circle.testCircle();
        // test the Dot class
        Dot.testDot();
        // test the Rectangle class
        Rectangle.testRectangle();
        // test the Square class
        Square.testSquare();
    }
}
