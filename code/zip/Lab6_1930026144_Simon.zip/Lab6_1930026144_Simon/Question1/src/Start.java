
public class Start {
    public static void main(String[] args) {
        // test the Shape class
        Shape.testShape();
    }
}
