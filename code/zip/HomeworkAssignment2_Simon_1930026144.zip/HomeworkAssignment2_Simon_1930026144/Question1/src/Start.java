
public class Start {
	public static void main(String[] args) {
        // test code
        Code.testCode();
        // test Assignment
        Assignment.testAssignment();
        // test Student
        Student.testStudent();
        // test Teacher
        Teacher.testTeacher();
        
    }
}
