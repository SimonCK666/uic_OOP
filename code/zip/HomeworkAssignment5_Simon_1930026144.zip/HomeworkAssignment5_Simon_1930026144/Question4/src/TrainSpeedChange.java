
public class TrainSpeedChange extends Exception {
    public TrainSpeedChange(String msg) {
        super(msg);
    }
}
