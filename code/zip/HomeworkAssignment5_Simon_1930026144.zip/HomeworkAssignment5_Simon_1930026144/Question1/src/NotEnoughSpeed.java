
public class NotEnoughSpeed extends Exception {
    public NotEnoughSpeed(String msg) {
        // create the constructor
        super(msg);
    }
}
