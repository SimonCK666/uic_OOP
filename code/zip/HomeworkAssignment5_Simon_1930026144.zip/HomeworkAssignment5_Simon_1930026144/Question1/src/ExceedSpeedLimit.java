
public class ExceedSpeedLimit extends Exception {
    public ExceedSpeedLimit(String msg) {
        // create the constructor
        super(msg);
    }
}
