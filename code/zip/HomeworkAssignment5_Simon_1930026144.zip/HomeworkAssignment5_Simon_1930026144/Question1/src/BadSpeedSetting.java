
public class BadSpeedSetting extends Exception {
    public BadSpeedSetting(String msg) {
        // create the constructor
        super(msg);
    }
}
