
public class BadAltitudeSetting extends Exception {
    public BadAltitudeSetting(String msg) {
        super(msg);
    }
}
