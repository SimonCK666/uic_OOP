
public class Start {
    public static void main(String[] args) {
    	// test code
        Cat.testCat();
        Dog.testDog();
        Student.testStudent();
        Animal.testAnimal();
        Bird.testBird();
        Chicken.testChicken();
        LivingThing.testLivingThing();
    }
}
