
public class Start {
    public static void main(String[] args) {
        // test Course class
        Course.testCourse();
        // test MajorRequired
        MajorRequired.testMajorRequired();
        // test MajorElective
        MajorElective.testMajorElective();
        // test Base class
        Base.testBase();
    }
}
