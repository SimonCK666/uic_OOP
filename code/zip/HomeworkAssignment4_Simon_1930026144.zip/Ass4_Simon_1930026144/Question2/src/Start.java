
public class Start {
    public static void main(String[] args) {
        // test Course class
        Course.testCourse();
        // test MajorRequired
        MajorRequired.testMajorRequired();
    }
}
