
public interface Learnable {
    // method getCode
    String getCode();
    // method getTitle
    String getTitle();
    // method getPreRequisite();
    Learnable getPreRequisite();
}
