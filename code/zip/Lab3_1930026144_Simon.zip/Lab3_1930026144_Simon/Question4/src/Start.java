
public class Start {
	// test the code
    public static void main(String[] args) {
        Student.testStudent();
    }
}
