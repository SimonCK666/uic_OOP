
public class Start {
    public static void main(String[] args) {
        // test the Sport class
        Sport.testSport();
        // test the Tennis class
        Tennis.testTennis();
        // test the Running class
        Running.testRunning();
        // test the Marathon class
        Marathon.testMarathon();
        // test the HalfMarathon class
        HalfMarathon.testHalfMarathon();
    }
}
