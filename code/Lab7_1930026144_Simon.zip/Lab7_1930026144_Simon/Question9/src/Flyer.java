
public interface Flyer {
    // getName method
    public String getName();
    // canFly Method
    public boolean canFly();
    // isDangerous method
    public boolean isDangerous();
}


// can not test objects from the Animal, Dog and Bird classes through the Flyer interface
// class Airplane need to be changed the others do not need to be changed