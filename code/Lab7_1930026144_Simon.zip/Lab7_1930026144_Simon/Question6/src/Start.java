
public class Start {
    public static void main(String[] args) {
        // test the Animal class
        Animal.testAnimal();
        // test the Dog class
        Dog.testDog();
        // test the Bird class
        Bird.testBird();
        // test the Magpie class
        Magpie.testMagpie();
        // test the Ostrich class
        Ostrich.testOstrich();
        // test thhe Pegasus calss
        Pegasus.testPegasus();
    }
}
