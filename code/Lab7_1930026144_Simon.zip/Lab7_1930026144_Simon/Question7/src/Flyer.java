
public interface Flyer {
    // getName method
    public String getName();
    // canFly Method
    public boolean canFly();
}


// can not test objects from the Animal, Dog and Bird classes through the Flyer interface